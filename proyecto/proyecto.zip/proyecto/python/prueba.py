from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
import requests
import json

# Crear un engine para comunicarse con la base de datos
user = 'reto1'
password = 'snfjaewfjoJAShjfjwJFhjfHJFWEHSVH'
host = 'localhost'
port = '5433'
database = 'pruebas_reto1'

# Hacemos la conexión
connection_str = f'postgresql://{user}:{password}@{host}:{port}/{database}'
# SQLAlchemy engine
engine = create_engine(connection_str)

# Definir la base
Base = declarative_base()

# Definir las tablas
class Usuarios(Base):
    __tablename__ = 'Usuarios'
    id = Column(Integer, primary_key=True)
    NombreUsuario = Column(String)
    Contrasena = Column(String)
    Email = Column(String)
    relacion_comentarios = relationship("Comentarios", back_populates="relacion_usuarios")

class Comentarios(Base):
    __tablename__ = 'Comentarios'
    id = Column(Integer, primary_key=True)
    maxCaracteres = Column(String)
    Usuario_id = Column(Integer, ForeignKey('Usuarios.id'))
    relacion_usuarios = relationship("Usuarios", back_populates="relacion_comentarios")

class Partidos(Base):
    __tablename__ = 'Partidos'
    id = Column(Integer, primary_key=True)
    equipo_local = Column(String)
    equipo_visitante = Column(String)
    fecha = Column(String)
    marcador_local = Column(Integer) 
    marcador_visitante = Column(Integer)

# Crear las tablas en la base de datos
Base.metadata.create_all(engine)

def insertar_partidos_desde_json():
    url = "https://raw.githubusercontent.com/openfootball/football.json/d01ea3e43ea265b3a9fa4fe59f5fe77a817b482a/2024-25/it.1.json"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        partidos = data['matches'] 

        # Crear una sesión
        Sesion = sessionmaker(bind=engine)
        sesion = Sesion()

        for partido in partidos:
           
            
            if 'score' in partido and 'ft' in partido['score']: # Tener en cuenta que este if me filtra sólo los partidos con un resultado
                marcador_local = partido['score']['ft'][0]
                marcador_visitante = partido['score']['ft'][1]

            nuevo_partido = Partidos(
                equipo_local=partido['team1'], 
                equipo_visitante=partido['team2'],
                fecha=partido['date'],
                marcador_local=marcador_local, 
                marcador_visitante=marcador_visitante
            )
            sesion.add(nuevo_partido)



        """
        voy a comentar pasao a paso la insercción del json con el bucle:

         - for partido in partidos:
            esto lo que hace es pillar cada registro del json del array matches, es decir, obtiene toda la información de 1 partido cada vez que itera: un ejemplo de partido en la primera iteracción:


        {
            "round": "Matchday 1",
            "date": "2024-08-17",
            "time": "18:30",
            "team1": "Genoa CFC",
            "team2": "FC Internazionale Milano",
            "score": {
                "ht": [
                1,
                1
                ],
                "ft": [
                    2,
                    2
                    ]
            }
        }


        - if 'score' in partido and 'ft' in partido['score']   
            primero comprueba si la clave score es una clave de partido (que es todo el contenido específico de ese partido   y como no asignamos el .value() va a pillar la clave como si fuera .keys()  ) y comprueba también si el campo ft existe en score (que es un campo tipo array de la clave score)

        - marcador_local = partido['score']['ft'][0] y marcador_visitante = partido['score']['ft'][1]
            hacemos 2 variables, una para pillar los goles del equipo local y otra con los goles del visitante
        
        - nuevo_partido = Partidos(
                equipo_local=partido['team1'], 
                equipo_visitante=partido['team2'],
                fecha=partido['date'],
                marcador_local=marcador_local, 
                marcador_visitante=marcador_visitante
            )
                    Insertamos los registros del json en las variables declaradas en la clase Partidos
        """
        sesion.commit()
        sesion.close()
        print("Partidos insertados correctamente.")
    else:
        print("Error al insertar los datos de los partidos")




insertar_partidos_desde_json()