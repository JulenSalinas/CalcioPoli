# proyecto/python/validacion_inicio_sesion.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from prueba import Usuarios  


user = 'reto1'
password = 'snfjaewfjoJAShjfjwJFhjfHJFWEHSVH'
host = 'localhost'
port = '5433'
database = 'pruebas_reto1'

connection_str = f'postgresql://{user}:{password}@{host}:{port}/{database}'
engine = create_engine(connection_str)

def validar_inicio_sesion(nombre_usuario, contrasena):
    # Validar que el nombre de usuario no esté vacío
    if not nombre_usuario:
        return "El nombre de usuario es obligatorio."
    
    # Validar que la contraseña no esté vacía
    if not contrasena:
        return "La contraseña es obligatoria."
    




    Session = sessionmaker(bind=engine)
    session = Session()
    
    # Vemos si las credenciales coinciden
    usuario = session.query(Usuarios).filter_by(NombreUsuario=nombre_usuario, Contrasena=contrasena).first()
    
    session.close()

    if usuario:
        return "Inicio de sesión exitoso."
    else:
        return "Nombre de usuario o contraseña incorrectos."