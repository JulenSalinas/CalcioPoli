import psycopg2


def main():
    conn = psycopg2.connect('postgres://avnadmin:AVNS_XjP7RK0k3zfWXBJP6PI@pg-179667ea-retouno.e.aivencloud.com:10473/defaultdb?sslmode=require')

    query_sql = 'SELECT VERSION()'

    cur = conn.cursor()
    cur.execute(query_sql)

    version = cur.fetchone()[0]
    print(version)


if __name__ == "__main__":
    main()



    