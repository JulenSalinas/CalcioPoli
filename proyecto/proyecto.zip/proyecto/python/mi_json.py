
# primero instalar requests desde la consola
# conda install requests ; pip install requests

import requests
import json

# URL de la API de JSONPlaceholder para obtener datos de usuarios
url = "https://raw.githubusercontent.com/openfootball/football.json/d01ea3e43ea265b3a9fa4fe59f5fe77a817b482a/2024-25/it.1.json"

# Realiza una solicitud GET a la API
response = requests.get(url)

# Verifica si la solicitud fue exitosa (código de respuesta 200)
if response.status_code == 200:
    print(response.text) # el contenido de la respuesta como una cadena de texto.
    # Utiliza json.loads() para analizar la respuesta JSON
    #data = json.loads(response.text)
    data = response.json()
    print("Datos de usuarios de JSONPlaceholder:")
    print(data)
else:
    print(f"Error en la solicitud. Código de respuesta: {response.status_code}")