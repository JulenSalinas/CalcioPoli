from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import declarative_base
# Crear un engine para comunicarse con la base de datos
#engine = create_engine('sqlite:///productos.sqlite')
#engine = create_engine('postgresql://<usuario>:<contraseña>@<host>/<base_de_datos>')
#"dbname='mydb' user='miusuario' host='localhost'"

# engine = create_engine('postgresql://alejandro:fuq73gtnu931we0sJJn¡240h@localhost/TareaSQLAlchemyJulenAlejandro')




user = 'reto1'
password = 'snfjaewfjoJAShjfjwJFhjfHJFWEHSVH'
host = 'localhost'
port = '5433'
database = 'pruebas_reto1'


# for creating connection string
connection_str = f'postgresql://{user}:{password}@{host}:{port}/{database}'
# SQLAlchemy engine
engine = create_engine(connection_str)
# you can test if the connection is made or not
try:
    with engine.connect() as connection_str:
        print('Successfully connected to the PostgreSQL database')
        Base = declarative_base()
        # Definir una tabla
        from sqlalchemy import Column, Integer, String, ForeignKey
        from sqlalchemy.orm import relationship

except Exception as ex:
    print(f'Sorry failed to connect: {ex}')