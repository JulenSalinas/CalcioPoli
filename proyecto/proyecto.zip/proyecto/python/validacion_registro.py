# proyecto/python/validacion_registro.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import declarative_base
from prueba import Usuarios  

# Configuración de la base de datos
user = 'usuario_reto'
password = '123'
host = 'localhost'
port = '5433'
database = 'prueba_reto'


connection_str = f'postgresql://{user}:{password}@{host}:{port}/{database}'
engine = create_engine(connection_str)

def validar_registro(nombre_usuario, contrasena, email):
    # Vemos si el nombre de usuario está vacío o no
    if not nombre_usuario:
        return "El nombre de usuario es obligatorio."
    
    # 8 Caractéres mínimo en la contraseña
    if len(contrasena) < 8:
        return "La contraseña debe tener al menos 8 caracteres."
    
    # Si no hay un @ o un . no es un email
    if "@" not in email or "." not in email:
        return "El correo electrónico no es válido."
    
   


    Session = sessionmaker(bind=engine)
    session = Session()
    
    # Vemos si el usuario ya existe en la base de datos
    if session.query(Usuarios).filter_by(NombreUsuario=nombre_usuario).first():
        session.close()
        return "El nombre de usuario ya está en uso."
    
    # Insertar el nuevo usuario en la base de datos
    nuevo_usuario = Usuarios(NombreUsuario=nombre_usuario, Contrasena=contrasena, Email=email)
    session.add(nuevo_usuario)
    
    try:
        session.commit()
    except:
        session.rollback()
        session.close()
        return "Error al registrar el usuario."
    
    session.close()
    return "Registro exitoso."